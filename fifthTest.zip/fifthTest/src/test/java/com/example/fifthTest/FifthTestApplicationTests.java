package com.example.fifthTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FifthTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
