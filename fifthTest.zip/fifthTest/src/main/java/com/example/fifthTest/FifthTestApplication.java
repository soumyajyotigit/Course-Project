package com.example.fifthTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FifthTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FifthTestApplication.class, args);
	}

}
